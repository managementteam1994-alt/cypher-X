/**
 * ============================================================
 * CYPHER X-MD — GAME ENGINE (Trivia / Quiz / Scramble)
 * ============================================================
 *
 * How a round works (built for big groups):
 *
 *  - Every member who answers correctly earns +5 points (once per round).
 *  - The round closes GAME_GRACE_SECONDS (default 5) after the FIRST correct
 *    answer, or when the timer runs out, or immediately in "first" mode.
 *  - Then the answer + who scored is posted and the next question follows.
 *
 * Trivia / Quiz: reply with A, B, C or D — ONE try per member per round.
 * Scramble: type the word — unlimited tries, only correct guesses count.
 *
 * Only real answer attempts are "consumed" by the game. Everything else in
 * the chat keeps flowing to anti-spam / anti-link / badwords as normal.
 * ============================================================
 */

const path = require('path');
const { readJsonCached } = require('./fastJson');
const { getPrefix } = require('./prefix');

const POINTS = 5;
const SUPPORTED = ['trivia', 'quiz', 'scramble'];

const envNum = (name, def) => {
    const v = process.env[name];
    return v === undefined || v === '' || Number.isNaN(Number(v)) ? def : Number(v);
};
const ROUND_SECONDS = () => envNum('GAME_ROUND_SECONDS', 30);
const GRACE_SECONDS = () => envNum('GAME_GRACE_SECONDS', 5);
const BREAK_SECONDS = () => envNum('GAME_BREAK_SECONDS', 4);
const MAX_NAMES_SHOWN = 10;

// gameKey -> game. Keyed per session so two bot numbers in one group never clash.
const activeGames = new Map();
// gameKey|type|difficulty -> Set(question index) so repeat games don't repeat questions
const usedQuestions = new Map();


/* ============================================================
 * HELPERS
 * ============================================================ */

const gameKey = (sock, jid) => `${(sock && sock.sessionId) || 'main'}|${jid}`;
const isCurrent = game => activeGames.get(game.key) === game;

function getText(m, body = '') {
    return String(
        body ||
        m?.message?.conversation ||
        m?.message?.extendedTextMessage?.text ||
        m?.message?.imageMessage?.caption ||
        m?.message?.videoMessage?.caption ||
        ''
    ).trim();
}

function isCommand(text) {
    return /^[.!/#]/.test(String(text || '').trim());
}

function normalizeJid(jid) {
    return jid ? String(jid).replace(/:\d+(?=@)/, '').trim().toLowerCase() : null;
}

function normalizeAnswer(text) {
    return String(text || '')
        .normalize('NFKD')
        .toUpperCase()
        .replace(/[^\p{L}\p{N} ]/gu, '')
        .replace(/\s+/g, ' ')
        .trim();
}

// Strict on purpose: "A lot of people..." must NOT count as answer "A".
// Accepts: A, a, A), (A), A., option b, answer: c, ans d
function parseChoice(text) {
    const m = String(text || '')
        .trim()
        .toUpperCase()
        .match(/^(?:(?:OPTION|ANSWER|ANS)\s*[:\-]?\s*)?\(?([A-D])\)?[.!)]?$/);
    return m ? m[1] : null;
}

function shuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

async function send(game, text, mentions) {
    try {
        const content = { text: String(text) };
        if (mentions && mentions.length) content.mentions = mentions;
        await game.sock.sendMessage(game.jid, content);
    } catch (error) {
        console.error('❌ [GAME SEND ERROR]:', error.message || error);
    }
}

function clearTimers(game) {
    for (const t of ['timer', 'graceTimer', 'breakTimer']) {
        if (game[t]) {
            clearTimeout(game[t]);
            game[t] = null;
        }
    }
}

/**
 * The real member who sent the message (never the group JID).
 * Works for normal members, LID-addressed groups and the owner
 * playing from the bot's own phone (fromMe).
 */
function getPlayer(sock, m) {
    const key = m?.key || {};
    let id = key.participant || m?.participant || null;

    if (!id && key.fromMe) id = sock?.user?.id || null;
    if (!id || String(id).endsWith('@g.us') || String(id).includes('@broadcast')) return null;

    id = normalizeJid(id);
    const alt = normalizeJid(key.participantAlt || key.participantPn || '');
    const phoneJid = [id, alt].find(j => j && /@s\.whatsapp\.net$/.test(j)) || null;
    const number = phoneJid ? phoneJid.split('@')[0] : null;

    const name =
        (key.fromMe && sock?.user?.name) ||
        m?.pushName ||
        m?.verifiedBizName ||
        (number ? `+${number}` : 'Player');

    return { id, name, phoneJid };
}


/* ============================================================
 * QUESTION PREPARATION
 * ============================================================ */

function scrambleWord(word) {
    const scrambleOne = w => {
        const letters = w.split('');
        if (letters.length < 2 || new Set(letters).size < 2) return w;
        for (let i = 0; i < 25; i++) {
            const s = shuffle(letters).join('');
            if (s !== w) return s;
        }
        return letters.reverse().join('');
    };
    return word.split(' ').map(scrambleOne).join(' ');
}

const REFERS_TO_OTHER_OPTIONS = /\b(above|both|all of|none of)\b/i;

function prepareChoiceQuestion(raw) {
    const text = raw?.question || raw?.q || raw?.text || '';
    const answerRaw = String(raw?.answer ?? raw?.correctAnswer ?? raw?.correct ?? '').trim();
    if (!text || !answerRaw) return null;

    let entries = [];
    if (Array.isArray(raw.options)) {
        entries = raw.options.map((t, i) => [String.fromCharCode(65 + i), String(t)]);
    } else if (raw.options && typeof raw.options === 'object') {
        entries = Object.entries(raw.options)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([k, v]) => [String(k).toUpperCase(), String(v)]);
    }

    // No options -> typed answer
    if (!entries.length) {
        return {
            kind: 'text',
            text,
            options: [],
            acceptable: [normalizeAnswer(answerRaw)],
            answerLabel: answerRaw
        };
    }

    const correctEntry =
        entries.find(([k]) => k === answerRaw.toUpperCase()) ||
        entries.find(([, v]) => normalizeAnswer(v) === normalizeAnswer(answerRaw));
    if (!correctEntry) return null;

    // Reshuffle options every round (keeps answers from being memorised),
    // unless an option refers to other options ("All of the above").
    let items = entries.map(([, v]) => ({ text: v, correct: v === correctEntry[1] }));
    if (!entries.some(([, v]) => REFERS_TO_OTHER_OPTIONS.test(v))) items = shuffle(items);

    const options = items.slice(0, 4).map((it, i) => ({ letter: String.fromCharCode(65 + i), text: it.text }));
    const correct = options.find((o, i) => items[i].correct);
    if (!correct) return null;

    return {
        kind: 'choice',
        text,
        options,
        correctLetter: correct.letter,
        answerLabel: `${correct.letter}. ${correct.text}`
    };
}

function prepareScrambleQuestion(raw) {
    const word = String(raw?.word || raw?.answer || '').trim().toUpperCase();
    if (!word) return null;
    return {
        kind: 'scramble',
        text: 'Unscramble this word:',
        options: [],
        scrambled: scrambleWord(word),
        hint: raw.hint || '',
        length: word.replace(/ /g, '').length,
        acceptable: [normalizeAnswer(word)],
        answerLabel: word
    };
}


/* ============================================================
 * FORMATTING
 * ============================================================ */

const ICON = { trivia: '🧠', quiz: '📝', scramble: '🔀' };

function formatRound(game) {
    const q = game.round.q;
    const head = `${ICON[game.type]} *${game.type.toUpperCase()}* — Round ${game.current + 1}/${game.total}`;
    const points = game.mode === 'first'
        ? `⭐ +${POINTS} points for the *first* correct answer`
        : `⭐ +${POINTS} points for *every* correct answer`;
    const secs = ROUND_SECONDS();

    if (q.kind === 'scramble') {
        let out = `${head}\n\n${q.text}\n\n👉 *${q.scrambled.split('').join(' ')}*\n(${q.length} letters)`;
        if (q.hint) out += `\n💡 Hint: ${q.hint}`;
        return `${out}\n\n✍️ Type the word • ⏳ ${secs}s\n${points}`;
    }

    let out = `${head}\n\n❓ ${q.text}\n`;
    if (q.options.length) {
        out += '\n' + q.options.map(o => `${o.letter}. ${o.text}`).join('\n') + '\n';
        const ls = q.options.map(o => o.letter);
        const list = ls.length > 1 ? `${ls.slice(0, -1).join(', ')} or ${ls[ls.length - 1]}` : ls[0];
        out += `\n✍️ Reply *${list}* — one try each`;
    } else {
        out += '\n✍️ Type your answer';
    }
    return `${out} • ⏳ ${secs}s\n${points}`;
}

function sortedScores(game) {
    return [...game.scores.values()].sort(
        (a, b) => b.points - a.points || b.correct - a.correct || a.firstAt - b.firstAt
    );
}

const MEDALS = ['🥇', '🥈', '🥉'];

function boardLines(entries, limit, mentions) {
    return entries.slice(0, limit).map((e, i) => {
        let label = e.name;
        if (mentions && e.phoneJid) {
            label = `@${e.phoneJid.split('@')[0]}`;
            mentions.push(e.phoneJid);
        }
        return `${MEDALS[i] || `${i + 1}.`} ${label} — *${e.points}* pts (${e.correct} correct)`;
    }).join('\n');
}

function getScoresText(game) {
    const entries = sortedScores(game);
    if (!entries.length) return '📊 Nobody has scored yet.';
    return `📊 *SCORES* — Round ${Math.max(game.current + 1, 1)}/${game.total}\n\n${boardLines(entries, 10)}`;
}


/* ============================================================
 * GAME FLOW
 * ============================================================ */

async function startGame(sock, jid, type, rounds = 5, difficulty = 'all', options = {}) {
    type = String(type || '').toLowerCase();
    const prefix = getPrefix();
    const tmp = { sock, jid };

    if (!SUPPORTED.includes(type)) {
        await send(tmp, `🚧 *${type}* isn't available yet.\n\nPlayable now: *trivia*, *quiz*, *scramble*\nExample: ${prefix}game start trivia easy 10`);
        return false;
    }

    const key = gameKey(sock, jid);
    if (activeGames.has(key)) {
        await send(tmp, `⚠️ A game is already running here.\nUse *${prefix}game stop* first.`);
        return false;
    }

    difficulty = String(difficulty || 'all').toLowerCase();
    const list = readJsonCached(path.join(__dirname, '..', 'games', `${type}.json`), []);
    const all = (Array.isArray(list) ? list : list.questions || []).map((raw, index) => ({ raw, index }));

    const levelOf = x => String(x.raw.difficulty || '').toLowerCase();
    let pool = difficulty === 'all' ? all : all.filter(x => levelOf(x) === difficulty);

    if (!pool.length) {
        const levels = [...new Set(all.map(levelOf).filter(Boolean))];
        await send(tmp, `❌ No *${difficulty}* ${type} questions.\nAvailable levels: ${levels.join(', ')}, all`);
        return false;
    }

    // Skip questions this group already played (until the pool runs dry)
    const usedKey = `${key}|${type}|${difficulty}`;
    let used = usedQuestions.get(usedKey);
    if (!used) usedQuestions.set(usedKey, (used = new Set()));
    let fresh = pool.filter(x => !used.has(x.index));
    if (fresh.length < Math.min(rounds, pool.length)) {
        used.clear();
        fresh = pool;
    }

    const prepare = type === 'scramble' ? prepareScrambleQuestion : prepareChoiceQuestion;
    const prepared = shuffle(fresh)
        .map(x => ({ q: prepare(x.raw), index: x.index }))
        .filter(x => x.q);

    if (!prepared.length) {
        await send(tmp, `❌ No playable ${type} questions found.`);
        return false;
    }

    const total = Math.min(rounds, prepared.length);
    const chosen = prepared.slice(0, total);
    chosen.forEach(x => used.add(x.index));

    const game = {
        key,
        jid,
        sock,
        type,
        difficulty,
        mode: options.mode === 'first' ? 'first' : 'all',
        total,
        questions: chosen.map(x => x.q),
        current: -1,
        round: null,
        scores: new Map(),
        timer: null,
        graceTimer: null,
        breakTimer: null,
        startedAt: Date.now()
    };
    activeGames.set(key, game);

    const grace = GRACE_SECONDS();
    let intro =
        `${ICON[type]} *${type.toUpperCase()} STARTING!*\n\n` +
        `📊 Level: *${difficulty}* • Rounds: *${total}* • ⏱ ${ROUND_SECONDS()}s each\n`;
    if (total < rounds) intro += `ℹ️ Only ${total} ${difficulty} questions available.\n`;
    intro += game.mode === 'first'
        ? `⭐ First correct answer each round wins *${POINTS} points*.`
        : `⭐ Everyone who answers correctly gets *${POINTS} points*` +
          (grace > 0 ? `\n⚡ Each round closes ${grace}s after the first correct answer.` : '.');
    intro += '\n\nGet ready…';

    await send(game, intro);

    if (isCurrent(game)) {
        game.breakTimer = setTimeout(() => nextRound(game).catch(logErr), 3000);
    }
    return true;
}

const logErr = e => console.error('🔥 [GAME ERROR]:', e);

async function nextRound(game) {
    if (!isCurrent(game)) return;
    clearTimers(game);

    game.current++;
    if (game.current >= game.total) {
        await finishGame(game.sock, game.jid);
        return;
    }

    game.round = {
        open: true,
        q: game.questions[game.current],
        attempted: new Set(),
        correctIds: new Set(),
        correct: []
    };

    // Arm the timer BEFORE the (possibly queued) send so it never starts late.
    game.timer = setTimeout(() => closeRound(game, 'timeout').catch(logErr), ROUND_SECONDS() * 1000);
    await send(game, formatRound(game));
}

async function closeRound(game, reason) {
    if (!isCurrent(game) || !game.round || !game.round.open) return;

    // Close synchronously so answers arriving during the awaits below are ignored.
    const round = game.round;
    round.open = false;
    clearTimers(game);

    let msg = `${round.correct.length || reason !== 'timeout' ? '✅' : '⏰ Time\'s up!\n✅'} *Round ${game.current + 1}/${game.total}* — Answer: *${round.q.answerLabel}*`;

    if (round.correct.length) {
        const names = round.correct.map(c => c.name);
        const shown = names.slice(0, MAX_NAMES_SHOWN).join(', ');
        const more = names.length > MAX_NAMES_SHOWN ? ` +${names.length - MAX_NAMES_SHOWN} more` : '';
        msg += `\n\n🎉 *${round.correct.length}* correct (+${POINTS} each): ${shown}${more}`;
    } else {
        msg += '\n\n😅 Nobody got it.';
    }

    const top = sortedScores(game);
    if (top.length && game.current + 1 < game.total) {
        msg += `\n\n🏆 *Top ${Math.min(3, top.length)}*\n${boardLines(top, 3)}`;
    }

    await send(game, msg);

    if (isCurrent(game)) {
        game.breakTimer = setTimeout(() => nextRound(game).catch(logErr), BREAK_SECONDS() * 1000);
    }
}

function scheduleClose(game) {
    const grace = GRACE_SECONDS();
    if (game.mode === 'first' || grace <= 0) {
        closeRound(game, 'answered').catch(logErr);
    } else if (!game.graceTimer) {
        game.graceTimer = setTimeout(() => closeRound(game, 'answered').catch(logErr), grace * 1000);
    }
}

function award(game, player) {
    let entry = game.scores.get(player.id);
    if (!entry) {
        entry = { id: player.id, name: player.name, phoneJid: player.phoneJid, points: 0, correct: 0, firstAt: Date.now() };
        game.scores.set(player.id, entry);
    }
    entry.points += POINTS;
    entry.correct += 1;
    if (player.name && !/^\+?\d+$/.test(player.name)) entry.name = player.name;
    if (!entry.phoneJid && player.phoneJid) entry.phoneJid = player.phoneJid;
    game.round.correct.push({ id: player.id, name: entry.name });
    game.round.correctIds.add(player.id);
}


/* ============================================================
 * ANSWER HANDLER  (called for every text message by the router)
 * Returns true ONLY when the message was a real answer attempt.
 * ============================================================ */

async function handleGameMessage(sock, m, from, body = '') {
    try {
        if (!from || typeof from !== 'string') return false;

        const game = activeGames.get(gameKey(sock, from));
        if (!game || !game.round || !game.round.open) return false;

        game.sock = sock; // always use the live socket (survives reconnects)

        const text = getText(m, body);
        if (!text || isCommand(text)) return false;

        const round = game.round;
        const q = round.q;

        // ---- is this even an answer attempt? (otherwise it's just chat) ----
        let letter = null;
        if (q.kind === 'choice') {
            letter = parseChoice(text);
            if (!letter || !q.options.some(o => o.letter === letter)) return false;
        } else if (!q.acceptable.includes(normalizeAnswer(text))) {
            return false; // typed answers: wrong guesses are ignored
        }

        const player = getPlayer(sock, m);
        if (!player) {
            console.warn('⚠️ [GAME] Could not identify the sender of an answer.');
            return false;
        }

        // ---- everything below is synchronous: no double scoring possible ----
        if (q.kind === 'choice') {
            if (round.attempted.has(player.id)) return true; // one try per round
            round.attempted.add(player.id);
            if (letter !== q.correctLetter) return true;
        } else if (round.correctIds.has(player.id)) {
            return true;
        }

        award(game, player);
        scheduleClose(game);
        return true;

    } catch (error) {
        console.error('🔥 [GAME ANSWER ERROR]:', error);
        return false;
    }
}


/* ============================================================
 * FINISH / STOP
 * ============================================================ */

async function finishGame(sock, jid, { stopped = false } = {}) {
    const game = activeGames.get(gameKey(sock, jid));
    if (!game) return false;

    game.sock = sock || game.sock;
    clearTimers(game);
    activeGames.delete(game.key); // remove first: no late timer can touch it

    const entries = sortedScores(game);
    const mentions = [];

    let msg = stopped
        ? `🛑 *${game.type.toUpperCase()} STOPPED*\n\n`
        : `🏁 *${game.type.toUpperCase()} FINISHED!*\n\n`;

    if (!entries.length) {
        msg += '😔 Nobody scored any points.';
    } else {
        msg += `🏆 *FINAL SCORES*\n\n${boardLines(entries, 10, mentions)}`;
        if (entries.length > 10) msg += `\n…and ${entries.length - 10} more player(s)`;
        if (!stopped) msg += `\n\n👑 Winner: *${entries[0].name}* — congratulations!`;
    }

    await send(game, msg, mentions);
    return true;
}

async function stopGame(sock, jid) {
    return finishGame(sock, jid, { stopped: true });
}

function getActiveGame(sock, jid) {
    return activeGames.get(gameKey(sock, jid)) || null;
}

module.exports = {
    activeGames,
    SUPPORTED,
    startGame,
    handleGameMessage,
    finishGame,
    stopGame,
    getActiveGame,
    getScoresText,
    normalizeAnswer,
    parseChoice
};

// Small concurrency + spacing limiter. run(fn) resolves with fn's result.
function createLimiter(max = 1, gapMs = 0) {
    let active = 0;
    let last = 0;
    let timer = null;
    const queue = [];

    const pump = () => {
        if (timer || active >= max || !queue.length) return;
        const wait = Math.max(0, last + gapMs - Date.now());
        if (wait > 0) {
            timer = setTimeout(() => { timer = null; pump(); }, wait);
            return;
        }
        const { fn, resolve, reject } = queue.shift();
        active++;
        last = Date.now();
        Promise.resolve().then(fn).then(resolve, reject).finally(() => {
            active--;
            pump();
        });
        pump();
    };

    const run = fn => new Promise((resolve, reject) => {
        queue.push({ fn, resolve, reject });
        pump();
    });
    run.pending = () => queue.length + active;
    return run;
}

module.exports = { createLimiter };

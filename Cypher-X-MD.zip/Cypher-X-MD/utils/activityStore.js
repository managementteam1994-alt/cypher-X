const fs = require('fs');

// In-memory activity counters with debounced, atomic disk writes.
// (Was: parse + rewrite the whole file synchronously on EVERY message.)
const FLUSH_MS = Number(process.env.ACTIVITY_FLUSH_MS || 5000);
const stores = new Map();

function diskMtime(file) {
    try { return fs.statSync(file).mtimeMs; } catch { return 0; }
}

function load(file) {
    try {
        if (fs.existsSync(file)) {
            const d = JSON.parse(fs.readFileSync(file, 'utf8'));
            if (d && typeof d === 'object') return d;
        }
    } catch (e) {
        console.error('[ACTIVITY] load failed:', e.message);
    }
    return {};
}

function getActivity(file) {
    let s = stores.get(file);
    const onDisk = diskMtime(file);
    // Another module (e.g. a reset command) wrote the file: its version wins.
    if (!s || (onDisk && s.mtime && onDisk !== s.mtime)) {
        if (s && s.timer) clearTimeout(s.timer);
        s = { file, data: load(file), dirty: false, timer: null, mtime: onDisk };
        stores.set(file, s);
    }
    return s.data;
}

function flush(s) {
    if (s.timer) { clearTimeout(s.timer); s.timer = null; }
    if (!s.dirty) return;
    try {
        const tmp = `${s.file}.tmp`;
        fs.writeFileSync(tmp, JSON.stringify(s.data));
        fs.renameSync(tmp, s.file);
        s.dirty = false;
        s.mtime = diskMtime(s.file);
    } catch (e) {
        console.error('[ACTIVITY] flush failed:', e.message);
    }
}

function markActivityDirty(file) {
    const s = stores.get(file);
    if (!s) return;
    s.dirty = true;
    if (!s.timer) {
        s.timer = setTimeout(() => flush(s), FLUSH_MS);
        if (s.timer.unref) s.timer.unref();
    }
}

function flushAll() {
    for (const s of stores.values()) flush(s);
}

process.on('exit', flushAll);
for (const sig of ['SIGINT', 'SIGTERM']) {
    process.once(sig, () => { flushAll(); process.exit(0); });
}

module.exports = { getActivity, markActivityDirty, flushAll };

const fs = require('fs');

// Parsed-JSON cache keyed by file. Re-parses only when the file changes on disk,
// so existing code that writes the file directly keeps working.
const cache = new Map();

function readJsonCached(file, fallback = {}) {
    try {
        const st = fs.statSync(file);
        const hit = cache.get(file);
        if (hit && hit.mtimeMs === st.mtimeMs && hit.size === st.size) return hit.data;
        const data = JSON.parse(fs.readFileSync(file, 'utf8'));
        cache.set(file, { mtimeMs: st.mtimeMs, size: st.size, data });
        return data;
    } catch {
        return fallback;
    }
}

module.exports = { readJsonCached };

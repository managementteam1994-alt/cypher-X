const { BOT_NAME, REPO_URL } = require('../bot/config');

module.exports = {
    name: 'repo',
    description: 'Show the bot repository',

    async execute(sock, m, from) {
        if (!REPO_URL) {
            return sock.sendMessage(from, { text: '❌ No repository link has been set (REPO_URL).' }, { quoted: m });
        }
        const message =
            `╭━━━〔 👑 ${BOT_NAME} 〕━━━╮\n` +
            `┃\n┃ 🔗 *Repository:*\n┃ ${REPO_URL}\n┃\n` +
            `╰━━━━━━━━━━━━━━━━━━━━━━╯`;
        await sock.sendMessage(from, { text: message }, { quoted: m });
    }
};

const fs = require('fs');
const path = require('path');
const { getPrefix } = require('../utils/prefix');

const MAIN_ACTIVITY_FILE = path.join(__dirname, '..', 'activity.json');

/*
 * ============================================================
 * Resolve the activity file for the session that is running
 * this command. Must match the naming used in bot/messageHandler.js
 * (activity.json for the main session, activity_<sessionId>.json
 * for every other paired session) or stats would be read from
 * the wrong file on multi-session hosts.
 * ============================================================
 */
function getActivityFilePath(sock, ctx) {
    const isMain =
        ctx?.isMain === true ||
        !sock?.sessionId ||
        sock.sessionId === 'main';

    if (isMain) {
        return MAIN_ACTIVITY_FILE;
    }

    const sessionId = ctx?.sessionId || sock.sessionId;

    return path.join(
        __dirname,
        '..',
        `activity_${sessionId}.json`
    );
}

function loadActivity(file) {
    try {
        if (!fs.existsSync(file)) {
            return {};
        }

        const data = JSON.parse(
            fs.readFileSync(file, 'utf8')
        );

        return data && typeof data === 'object' ? data : {};
    } catch (error) {
        console.error('🔥 [MSGS] Failed to read activity file:', error.message);
        return {};
    }
}

function normalizeRecord(record) {
    if (typeof record === 'number') {
        return { messages: record, lastActive: 0 };
    }

    if (!record || typeof record !== 'object') {
        return { messages: 0, lastActive: 0 };
    }

    return {
        messages: Number(record.messages) || 0,
        lastActive: Number(record.lastActive) || 0,
        text: Number(record.text) || 0,
        sticker: Number(record.sticker) || 0,
        image: Number(record.image) || 0,
        video: Number(record.video) || 0,
        audio: Number(record.audio) || 0,
        others: Number(record.others) || 0
    };
}

// "13 hours 16 minutes 23 seconds ago" style, precise to the second.
function formatLastSeen(timestamp) {
    if (!timestamp) {
        return 'No activity recorded';
    }

    const diffSec = Math.max(
        0,
        Math.floor((Date.now() - timestamp) / 1000)
    );

    const hours = Math.floor(diffSec / 3600);
    const minutes = Math.floor((diffSec % 3600) / 60);
    const seconds = diffSec % 60;

    return (
        `${hours} hour${hours === 1 ? '' : 's'} ` +
        `${minutes} minute${minutes === 1 ? '' : 's'} ` +
        `${seconds} second${seconds === 1 ? '' : 's'} ago`
    );
}

function getDisplayName(metadata, jid) {
    const member = (metadata?.participants || []).find(
        participant => participant.id === jid
    );

    return (
        member?.notify ||
        member?.name ||
        member?.verifiedName ||
        jid.split('@')[0]
    );
}

module.exports = {

    name: 'msgs',

    aliases: ['memberstats', 'msgstats'],

    description: 'Per-member message breakdown (text/sticker/image/video/audio) for this group',

    async execute(sock, m, from, args, isOwner, ctx) {

        if (!from.endsWith('@g.us')) {
            return sock.sendMessage(
                from,
                { text: '❌ This command can only be used inside a group.' },
                { quoted: m }
            );
        }

        try {
            const activityFile = getActivityFilePath(sock, ctx);
            const data = loadActivity(activityFile);
            const groupActivity = (data && data[from]) || {};

            const entries = Object.entries(groupActivity)
                .map(([jid, record]) => ({
                    jid,
                    ...normalizeRecord(record)
                }))
                .filter(entry => entry.messages > 0)
                .sort((a, b) => {
                    if (b.messages !== a.messages) {
                        return b.messages - a.messages;
                    }
                    return b.lastActive - a.lastActive;
                });

            if (!entries.length) {
                return sock.sendMessage(
                    from,
                    { text: 'ℹ️ No message activity recorded for this group yet.' },
                    { quoted: m }
                );
            }

            const limit = Math.min(
                Math.max(parseInt(args[0], 10) || entries.length, 1),
                100
            );

            let metadata = null;
            try {
                metadata = await sock.groupMetadata(from);
            } catch (metaErr) {
                metadata = null;
            }

            const prefix = getPrefix();
            const shown = entries.slice(0, limit);

            let text = `👑 *CYPHER X-MD — MEMBER MESSAGE STATS*\n.msgs\n\n`;

            for (const entry of shown) {
                const number = entry.jid.split('@')[0].replace(/[^0-9]/g, '');
                const name = metadata
                    ? getDisplayName(metadata, entry.jid)
                    : number;

                text += `Number : ${number}\n`;
                text += `Name : ${name}\n`;
                text += `Total Msgs : ${entry.messages}\n`;

                if (entry.text) text += `text : ${entry.text}\n`;
                if (entry.sticker) text += `sticker : ${entry.sticker}\n`;
                if (entry.image) text += `image : ${entry.image}\n`;
                if (entry.video) text += `video : ${entry.video}\n`;
                if (entry.audio) text += `audio : ${entry.audio}\n`;
                if (entry.others) text += `others : ${entry.others}\n`;

                text += `lastSeen : ${formatLastSeen(entry.lastActive)}\n\n`;
            }

            if (entries.length > shown.length) {
                text += `… and ${entries.length - shown.length} more. Use ${prefix}msgs ${entries.length} to see everyone.`;
            }

            await sock.sendMessage(
                from,
                { text: text.trim() },
                { quoted: m }
            );

        } catch (error) {
            console.error('🔥 [MSGS COMMAND ERROR]:', error);

            await sock.sendMessage(
                from,
                { text: '❌ Failed to load message stats for this group.' },
                { quoted: m }
            );
        }
    }
};

const {
    startGame,
    stopGame,
    getActiveGame,
    getScoresText
} = require('../utils/gameManager');

const { getPrefix } = require('../utils/prefix');
const { findParticipant, isAdminParticipant } = require('../utils/groupParticipants');
const riddleGame = require('./riddle');
const wordGames = require('./wordgames');
const { CREATOR_NUMBERS } = require('../bot/config');

const GAME_ALIASES = {
    triviagame: 'trivia',
    quizgame: 'quiz',
    scramblegame: 'scramble',
    guessnumber: 'guess',
    numberguess: 'guess',
    truth: 'truthordare',
    dare: 'truthordare',
    emojigame: 'emoji',
    emojiguess: 'emoji',
    movieemoji: 'movemoji',
    movieguess: 'movemoji',
    find: 'findemoji',
    lyric: 'lyrics',
    rhyming: 'rhyme',
    meme: 'memewar'
};

const PLAYABLE = ['trivia', 'quiz', 'scramble'];

const COMING_SOON = [
    'guess', 'truthordare', 'emoji', 'movemoji', 'findemoji',
    'lyrics', 'rhyme', 'taboo', '2truth1lie', 'memewar'
];

const LEVELS = ['easy', 'medium', 'hard', 'all', 'mixed'];

function normalizeGame(name) {
    const value = String(name || '').toLowerCase().trim();
    return GAME_ALIASES[value] || value;
}

function gameMenu(p) {
    return `
┏━━━ 🎮 *CYPHER X-MD GAMES* 🎮 ━━━┓
┃
┃ 🧠 *Trivia*
┃    ${p}game start trivia easy 10
┃
┃ 📝 *Quiz*
┃    ${p}game start quiz medium 10
┃
┃ 🔀 *Word Scramble*
┃    ${p}game start scramble easy 10
┃
┣━━━━━━━━━━━━━━━━━━━━━━━
┃ ⭐ Every member who answers correctly
┃    earns *5 points*, then the next
┃    question follows.
┃
┃ 📌 Levels: easy • medium • hard • all
┃    (scramble: easy • hard • all)
┃ 📌 Rounds: 5 – 100 (default 5)
┃ 📌 Add *first* at the end so only the
┃    first correct answer scores:
┃    ${p}game start trivia easy 10 first
┃
┃ 📊 Scores:  ${p}game scores
┃ 🛑 Stop:    ${p}game stop
┃
┃ 🚧 Coming soon: ${COMING_SOON.join(', ')}
┃
┗━━━ 👑 *CYPHER X-MD* 👑 ━━━┛
`;
}

module.exports = {
    name: 'game',
    description: 'Group games: trivia, quiz and scramble',

    async execute(sock, m, from, args, isOwnerArg) {
        const prefix = getPrefix();
        const reply = text => sock.sendMessage(from, { text }, { quoted: m });

        const isGroup = from.endsWith('@g.us');
        const sender = m.key.participant || m.key.remoteJid;
        const senderNumber = String(sender).replace(/[^0-9]/g, '');

        const isOwner =
            !!isOwnerArg ||
            !!m.key.fromMe ||
            CREATOR_NUMBERS.includes(senderNumber);

        const action = String(args[0] || '').toLowerCase();

        // ---------- menu ----------
        if (!['start', 'stop', 'scores', 'score'].includes(action)) {
            return reply(gameMenu(prefix));
        }

        // ---------- scores (anyone) ----------
        if (action === 'scores' || action === 'score') {
            const game = getActiveGame(sock, from);
            return reply(game ? getScoresText(game) : '❌ No game is running right now.');
        }

        // ---------- admin check (LID-safe) ----------
        let isAdmin = false;
        if (isGroup && !isOwner) {
            try {
                const metadata = await sock.groupMetadata(from);
                const participant =
                    findParticipant(metadata, m.key.participant) ||
                    findParticipant(metadata, m.key.participantAlt);
                isAdmin = isAdminParticipant(participant);
            } catch (error) {
                console.error('Game admin check error:', error);
            }
        }

        if (!isOwner && !isAdmin) {
            return reply('❌ *Access Denied!*\n\nOnly group admins and the bot owner can start or stop games.');
        }

        // ---------- stop ----------
        if (action === 'stop') {
            let stopped = await stopGame(sock, from);

            for (const other of [riddleGame, wordGames]) {
                if (
                    other &&
                    typeof other.isActive === 'function' &&
                    other.isActive(from) &&
                    typeof other.stop === 'function'
                ) {
                    await other.stop(sock, from);
                    stopped = true;
                }
            }

            return stopped ? undefined : reply('❌ No game is running right now.');
        }

        // ---------- start ----------
        if (!isGroup) {
            return reply('❌ Games can only be played in WhatsApp groups.');
        }

        const gameType = normalizeGame(args[1]);

        if (!PLAYABLE.includes(gameType)) {
            if (COMING_SOON.includes(gameType)) {
                return reply(`🚧 *${gameType}* isn't available yet.\n\nPlayable now: trivia, quiz, scramble.`);
            }
            return reply('❌ *Invalid game!*\n\n' + gameMenu(prefix));
        }

        // Read the remaining words in any order: level, rounds, "first"
        let difficulty = 'all';
        let rounds = 5;
        let mode = 'all';

        for (const raw of args.slice(2)) {
            const word = String(raw).toLowerCase();
            if (LEVELS.includes(word)) difficulty = word === 'mixed' ? 'all' : word;
            else if (word === 'first') mode = 'first';
            else if (/^\d+$/.test(word)) rounds = parseInt(word, 10);
        }

        if (rounds < 5) {
            return reply(`❌ Minimum is *5 rounds*.\n\nExample:\n${prefix}game start ${gameType} 5`);
        }
        if (rounds > 100) {
            return reply('❌ Maximum is *100 rounds*.');
        }

        // Don't run two games at once in the same group
        for (const other of [riddleGame, wordGames]) {
            if (other && typeof other.isActive === 'function' && other.isActive(from)) {
                return reply(`⚠️ Another game is running here. Use *${prefix}game stop* first.`);
            }
        }

        return startGame(sock, from, gameType, rounds, difficulty, { mode });
    }
};

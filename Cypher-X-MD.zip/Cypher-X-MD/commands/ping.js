const { CHANNEL_TEXT_LINK } = require('../bot/config');

module.exports = {
    name: 'ping',
    description: 'Check real-time latency with message editing',
    async execute(sock, m, from) {
        const start = Date.now();

        const loadingText = `┏━━━ 👑 *CYPHER X-MD* 👑 ━━━┓\n` +
                            `┃ Status: *PINGING* ✅\n` +
                            `┣━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `┃ 🏓 *Status:* Measuring latency...\n` +
                            `┗━━━ 👑 *CYPHER X-MD* 👑 ━━━┛\n` +
                            `> _Please wait_`;

        const sentMsg = await sock.sendMessage(from, { text: loadingText }, { quoted: m });

        const latency = Date.now() - start;

        const successText = `┏━━━ 👑 *CYPHER X-MD* 👑 ━━━┓\n` +
                            `┃ Status: *PONG* ✅\n` +
                            `┣━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `┃ 🏓 *Latency:* *${latency}ms*\n` +
                            `┗━━━ 👑 *CYPHER X-MD* 👑 ━━━┛\n` +
                            `> _Success_` + CHANNEL_TEXT_LINK;

        await sock.sendMessage(from, {
            text: successText,
            edit: sentMsg.key
        });
    }
};

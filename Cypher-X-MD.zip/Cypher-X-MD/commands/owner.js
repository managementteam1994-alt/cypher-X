const { BOT_NAME, CREATOR_NAME, DISPLAY_CREATOR_NUMBER } = require('../bot/config');

module.exports = {
    name: 'owner',
    description: 'Show the bot owner information',

    async execute(sock, m, from) {
        if (!DISPLAY_CREATOR_NUMBER) {
            return sock.sendMessage(from, { text: '❌ Owner number is not configured.' }, { quoted: m });
        }

        const text = `╭━━━━━━━━━━━━━━━━━━━━━━╮
┃      👑 *${BOT_NAME}* 👑
┃          *OWNER*
╰━━━━━━━━━━━━━━━━━━━━━━╯

◈ Name   : *${CREATOR_NAME}*
◈ Number : *@${DISPLAY_CREATOR_NUMBER}*

━━━━━━━━━━━━━━━━━━━━━━

🤖 *BOT*
◈ Name   : *${BOT_NAME}*`;

        await sock.sendMessage(
            from,
            { text, mentions: [`${DISPLAY_CREATOR_NUMBER}@s.whatsapp.net`] },
            { quoted: m }
        );
    }
};

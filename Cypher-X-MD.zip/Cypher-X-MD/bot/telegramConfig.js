require('dotenv').config();

// Create your own bot with @BotFather and put the token in .env.
// If it is empty the Telegram pairing gateway simply stays off.
module.exports = {
    TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || ''
};

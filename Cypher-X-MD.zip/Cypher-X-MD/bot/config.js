require('dotenv').config();

const digits = s => String(s || '').replace(/[^0-9]/g, '');
const bool = (v, d = false) => (v === undefined || v === '' ? d : String(v).toLowerCase() === 'true');

const BOT_NAME = process.env.BOT_NAME || 'Cypher X-MD';
const CREATOR_NAME = process.env.OWNER_NAME || 'Owner';

// OWNER_NUMBER: your WhatsApp number (country code, no +). Comma-separate for extras.
// The first number is the one the MAIN session pairs with.
const OWNER_NUMBERS = String(process.env.OWNER_NUMBER || '')
    .split(',')
    .map(digits)
    .filter(Boolean);
const DISPLAY_CREATOR_NUMBER = OWNER_NUMBERS[0] || '';

// Off by default. When true, OWNER_NUMBER gets owner rights on EVERY paired session
// (including other people's). Only enable it if you tell your users.
const HOST_ADMIN_ACCESS = bool(process.env.HOST_ADMIN_ACCESS, false);
const CREATOR_NUMBERS = HOST_ADMIN_ACCESS ? OWNER_NUMBERS : [];

const CHANNEL_LINK = process.env.CHANNEL_LINK || '';
const CHANNEL_TEXT_LINK = CHANNEL_LINK
    ? `\n\n📢 *Join ${BOT_NAME} Channel:*\n${CHANNEL_LINK}`
    : '';

const REPO_URL = process.env.REPO_URL || '';
const PUBLIC_URL = process.env.PUBLIC_URL || '';
const TELEGRAM_PAIRING_URL = process.env.TELEGRAM_PAIRING_URL || PUBLIC_URL || 'ask the owner';

module.exports = {
    BOT_NAME,
    CREATOR_NAME,
    DISPLAY_CREATOR_NUMBER,
    OWNER_NUMBERS,
    CREATOR_NUMBERS,
    HOST_ADMIN_ACCESS,
    CHANNEL_LINK,
    CHANNEL_TEXT_LINK,
    REPO_URL,
    PUBLIC_URL,
    TELEGRAM_PAIRING_URL
};
